console.log("welcome");

let msg = {
    text: "Hello from the popup!"
}

function start() {
    document.getElementById("myButton").onclick = grabData();
}
function grabData() {
    if (document.getElementById("userInput") !== null) {
        console.log(document.getElementById("userInput").innerHTML.values);
    }

}

start()

