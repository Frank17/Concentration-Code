console.log("Hello");

var blocked_subjects = ['sports', 'game', 'social media'];
var current_subject = '';
var paragraphs_arr = [];

let paragraphs = document.getElementsByTagName("p");
for (element of paragraphs) {
    paragraphs_arr.push(element.innerText);
    console.log('PARAGRAPH SAVED');
    // element.style["background-color"] = "#FF0000";
}
console.log(paragraphs_arr.join(' '));
// console.log(document.all[0]);


function checkSubject() {
    var HTTP = new XMLHttpRequest();
    var url = 'https://web.nightstarry.repl.co/dynamicTest';
    HTTP.open('POST', url, true);

    var data = new FormData();
    data.append('paragraphs', paragraphs_arr.join(' '));
    data.append('blocked', blocked_subjects);

    HTTP.send(data);

    HTTP.onreadystatechange = function () {
        if (HTTP.readyState == 4) {
            should_block_page = HTTP.responseText;
            console.log(should_block_page);
            for (let i = 0; i < blocked_subjects.length; i++) {
                //console.log('Subject: ' + i);
                //console.log('Web subject: ' + current_subject);
                if (should_block_page === "True") {
                    console.log('GO BACK');
                    document.documentElement.innerHTML = '';
                    document.documentElement.innerHTML = 'Website is blocked';
                    document.documentElement.scrollTop = 0;
                }
            }
        }
    }
    return;
}

checkSubject()


// chrome.runtime.onMessage.addListener(gotMessage);
// chrome.browserAction.onMessage.addListener(gotPopup);
// var num = 1;
// function gotMessage(message, sender, sendResponse) {
//     console.log(message.text);

//     if (message.text === "hi from the background script!" && num % 2 === 0) {
//         let paragraphs = document.getElementsByTagName("p");
//         for (element of paragraphs) {
//             element.style["background-color"] = "#FF0000";
//         }
//         num = num + 1;
//     }
//     else {
//         let paragraphs = document.getElementsByTagName("p");
//         for (element of paragraphs) {
//             element.style["background-color"] = "#000000";
//         }
//         num = num + 1;
//     }
// }

// function gotPopup(message, sender, sendResponse) {

// }
// https://websitesetup.org/javascript-cheat-sheet/
// https://websitesetup.org/
// <all_urls>
// "browser_action": {
//   "default_popup": "popup.html"